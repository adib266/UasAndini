package com.example.MyUasAndini.api

import com.example.MyUasAndini.Model.Model
import retrofit2.Call
import retrofit2.http.GET

interface ApiEndpoint {
    @GET("data.php")
    fun data() : Call<Model>
}